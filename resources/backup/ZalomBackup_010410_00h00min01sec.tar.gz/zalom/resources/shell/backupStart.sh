#!/bin/sh

cd /home/usr/zalomdev/public_html/typo3/ext/zalom/resources/shell
sh backup.sh

echo "END of Backup"