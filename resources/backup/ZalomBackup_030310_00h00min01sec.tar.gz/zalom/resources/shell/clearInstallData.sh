#!/bin/sh
# source config.sh

rm -r original_fileadmin
rm -r original_typo3conf
rm -r original_typo3temp
rm -r original_uploads

rm getData.sh
rm config.sh